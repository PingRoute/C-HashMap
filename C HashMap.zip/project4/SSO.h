int insertTrade(double[],int,double,int);

double findLow(double[],int);

double findHigh(double[],int);

double calculateFSO(double,double,double);

int insertFSO(double[],int,int,double);

double calculateSSO(double[],int);

int insertSSO(double [],int,int,double);

double calculateSL(int,double[]);
