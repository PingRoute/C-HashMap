struct list;

struct list *newList(struct list **,struct list ** ,int,double,int,char );

int check(struct list **,struct list **,int);

struct list *find(struct list **,struct list **,int);

int getQuantity(struct list**,struct list**,int);

int changeQuantity(struct list**,struct list**,int ,int);

void printList(struct list  **,struct list**,FILE *);

void changePriceAndQuantity(struct list **,struct list **,int,double,int);

int deleteList(struct list **,struct list** ,int);
