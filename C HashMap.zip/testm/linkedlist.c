#include<stdio.h>
#include<stdlib.h>
#include"linkedlist.h"
struct list{
  int id;
  double price;
  int quantity;
  char side;
  struct list *next;
};

struct list *newList(struct list **head,struct list **tail ,int id,double price,int quantity,char side){
  struct list *list=(struct list*)malloc(sizeof(struct list));
  list->id=id;
  list->price=price;
  list->quantity=quantity;
  list->side=side;
  
  if((*head)==NULL&&(*tail)==NULL){
    *head=list;
    *tail=list;
    (*tail)->next=NULL;
  }else{
    (*tail)->next=list;
    (*tail)=list;
    (*tail)->next=NULL;
  }
  return(list);
}
int check(struct list **head,struct list ** tail,int id){
  int check=1;
  struct list *temp;
  temp=(*head);
  if(temp==NULL){
    return 0;
  }
  while((temp!=NULL)&&temp->id!=id){
    check=0;  
    if(temp!=(*tail)){
      temp=temp->next;
    }
    if(temp->id==id){
      check=1;
      return check;
    }
    if(temp==(*tail)){
      return check;
    }
  }
 
  return check;
}
struct list *find(struct list **head,struct list **tail,int id){
  struct list *temp;
  temp=*head;
  while((temp->next)!=NULL){
    if(temp->id==id){
    
      return (temp);
    }else
      temp=temp->next;
  

  }
  return (temp); 
}

int getQuantity(struct list**head,struct list**tail,int id){
  return ((find(head,tail,id))->quantity);
}

int changeQuantity(struct list **head,struct list**tail,int id ,int quantity){
  int c;
  return find(head,tail,id)->quantity-=quantity;
}

void printList(struct list **head,struct list** tail,FILE *fileWriter){
  struct list *temp;
  
  temp=*head;
  //printf("start printlist\n");
  while(temp!=NULL){
    fprintf(fileWriter,"%d %c %d %lf\n",temp->id,temp->side,temp->quantity,temp->price);
    if(temp->next!=NULL){
    temp=temp->next;
    }else
      temp=NULL;
  }
  //printf("end print list\n");
}

void changePriceAndQuantity(struct list**head,struct list **tail,int id,double price,int quantity){
  find(head,tail,id)->quantity=quantity;
  find(head,tail,id)->price=price;
}

int deleteList(struct list **head,struct list**tail,int id){
  struct list *temp;
  struct list *temp2;
  temp=*head;
  while(check(head,tail,id)==1){

    if((*head)->id==id){
      temp=*head;
      *head=(temp->next);
      free(temp);
      return 0;
    
    }else if(((temp->next)==(*tail))&&(*tail)->id==id){
   
      free(*tail);
      *tail=temp;
      ((*tail)->next)=NULL;
      return 0;

    }else if(((temp->next)->id)==id){
      temp2=temp->next;
      temp->next=(temp->next)->next;
      free(temp2);
      return 0;

    }else{
      temp=temp->next;
    }
}
}
