#include<stdio.h>
int main(int argc,char *argv[]){
  int boo;
  char a[3]="-o";
  if (argc!=5){
    printf("too few arguments %d\n",argc);
  }
  if(argc==5){
    printf("%s,%s\n",argv[1],argv[3]);
    boo=strcmp(argv[1],"-i");
      printf("%d\n",boo);
      if(boo==0){
    printf("%s\n",argv[2]);
      }
      if(argv[3]==a){
    printf("%s\n",argv[4]);
      }
    printf("%d",boo);
  }
}
