int hashIndex(int);

struct list *newhashmap(int,double,int,char);

struct list *findH(int);

int getQuantityH(int);

int getPriceH(double);

void changeQuantityH(int,int);

void changePriceH(int,double);

int deleteH(int);

void changePrcieAndQuantityH(int, int,double);

void printHashmap(FILE *);
