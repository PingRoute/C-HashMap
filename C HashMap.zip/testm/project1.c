#include<stdio.h>
#include<stdlib.h>
#include"linkedlist.h"
#include"hashmap.h"
#define totalIndex 8


int main(int argc,char*argv[]){
  int hashTable[totalIndex];
  int x;
  FILE *fpread,*fpappend ,*fpwrite;
  FILE *fopne;
  int a=0;
  int b=0;

  char c;
  int id;
  char side;
  char symble[4];
  int quantity,quantity1;
  long double price;
  int tempid;
  int tempq;
  int i;
  int cmp1;
  int cmp2;
  int cmp3;
  struct list *head=NULL;
  struct list *tail=NULL;
 
  if(argc==6){
    fpread=stdin;
    fpwrite=stdout;
    for(i=0;i<=argc;i++){
    cmp1=strcmp(argv[i],"-i");
    cmp2=strcmp(argv[i],"-o");
    cmp3=strcmp(argv[i],"-h");    
    if(cmp1==0){
      fpread=fopen(argv[i+1],"r"); 
      a=1;
    }
    if(cmp2==0){
      fpwrite=fopen(argv[i+1],"w");   
      b=1;
    }
    if(cmp3==0&&a==1&&b==1){
    
   
      while((x=fscanf(fpread,"%c %d",&c,&id))!=EOF){
	if(c=='A'&&findH(id)==NULL){
	  fscanf(fpread," %c %s %d %Lf\n",&side,symble,&quantity,&price);	  
	  newhashmap(id,price,quantity,side);
	}
	if(c=='T'&&checkH(id)){
	  fscanf(fpread,"%s %d\n",symble,&quantity);
	  changeQuantityH(id,quantity);
	}
	if((c=='C')&&checkH(id)){
	  fscanf(fpread,"%s %d\n",symble,&quantity);
	  changeQuantityH(id,quantity);
	}
	if((c=='R')&&checkH(id)){
	  fscanf(fpread,"%s %d %Lf\n",symble,&quantity,&price);
	  changePriceAndQuantityH(id,quantity,price);
	}
	if((c=='X')&&checkH(id)){
	  fscanf(fpread,"%s\n",symble);
	  deleteH(id);
	}
      }
      printHashmap(fpwrite);
      close(fpread);
      close(fpwrite);
      return 0;
    }
  }
  }

  if(argc!=6){
    fpread=stdin;
    fpwrite=stdout;
    for(i=0;i<argc;i++){
 
      cmp1=strcmp(argv[i],"-i");
      cmp2=strcmp(argv[i],"-o");
      cmp3=strcmp(argv[i],"-h"); 
      if(cmp1==0){
	fpread=fopen(argv[i+1],"r");
      }
      if(cmp2==0){
	fpwrite=fopen(argv[i+1],"w");
      }
    }
    while((x=fscanf(fpread,"%c %d",&c,&id))!=EOF){

      if(c=='A'&&check(&head,&tail,id)==0){
	fscanf(fpread," %c %s %d %Lf\n",&side,symble,&quantity,&price);
	newList( &head,&tail,id,price,quantity,side);

      }
      if(c=='T'&&(check(&head,&tail,id)==1)){

	fscanf(fpread,"%s %d\n",symble,&quantity);
	changeQuantity(&head,&tail,id,quantity);
      }
       if((c=='C')&&check(&head,&tail,id)==1){
	fscanf(fpread,"%s %d\n",symble,&quantity);
	changeQuantity(&head,&tail,id,quantity);
      }
      if((c=='R')&&check(&head,&tail,id)==1){
	fscanf(fpread,"%s %d %Lf",symble,&quantity,&price);
	changePriceAndQuantity(&head,&tail,id,price,quantity);
      }

      if((c=='X')&&check(&head,&tail,id)==1){
	fscanf(fpread,"%s\n",symble);
	deleteList(&head,&tail,id);
      }
       }

    printList(&head,&tail,fpwrite);
    close(fpread);
    close(fpwrite);
    }
}
