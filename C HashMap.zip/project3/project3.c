#include<stdio.h>
#include<stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <string.h>
#include<signal.h>
#include "readBinary.h"
#include "hashmap.h"
#include "internalstorage.h"


char symbol[4];
int totalMessageCounter=0;
void sigintHandler(int signal){
  printf("Program killed after processing %d messages for symbol %s.\n",totalMessageCounter,symbol);
  exit(0);
}
void segfaultHandler(int signal){
  printf("Program died from a segmentation fault after processing %d messages for symbol %s.",totalMessageCounter,symbol);
  exit(0);
  }
int main(int argc,char* argv[]){
 
  FILE *fpread=stdin,*fpwrite=stdout,*IQwriter;
  static int i;
  fpread=stdin;
  fpwrite=stdout;
  int bFlag=0;
  int sFlag=0;
  int cc;
  int messageCount=1000;
  int tempPrice;

  int nFlag=1;
  char Xside;
  char strcpy[4];
  int iFlag=0;

  int c;
  
  signal(SIGINT,sigintHandler);
  signal(SIGSEGV,segfaultHandler);
  while ((cc=(getopt (argc, argv, "i:s:hbn:"))) != -1){
    switch(cc)
      {
      case'i':
	iFlag=1;
	fpread=fopen(optarg,"r");
	break;
      case'b':
	bFlag=1;
	break;
      case's':
	sFlag=1;
	strncpy(symbol,optarg,4);
	break;
      case'n':
	messageCount=atoi(optarg);
	/* IQwriter=fopen("iq.txt","w"); */
	nFlag=1;
	break;
      case'?':
	printf("please enter corrct command\n");
      }
  }
  if(bFlag==1){
  
    fpwrite=fopen("ob.txt","w");
    IQwriter=fopen("iq.txt","w");
    
    struct AStruct Abuffer;
    struct XStruct Xbuffer;
    struct RStruct Rbuffer;
    struct CStruct Cbuffer;
    struct TStruct Tbuffer;
    struct readType type;
    struct list *headBuy=NULL,*tailBuy=NULL,*headSell=NULL,*tailSell=NULL;
    i=0;
    while(feof(fpread)==0){
    
      fread(&type,sizeof(struct readType),1,fpread);
      if(type.messageType=='A'){		
	fread(&Abuffer,sizeof(struct AStruct),1,fpread);
	if(Abuffer.symbol[0]==symbol[0]){	   
	  newhashmap(Abuffer.id,Abuffer.price,Abuffer.quantity,Abuffer.side);
	  if(nFlag==1){
	    i++;	 
	    totalMessageCounter++;
	    if(Abuffer.side=='B')
	      insert(&headBuy,&tailBuy,Abuffer.id);
	    else
	      insert(&headSell,&tailSell,Abuffer.id);
	  }
	}
      }else if(type.messageType=='T'||type.messageType=='C'){
	fread(&Tbuffer,sizeof(struct TStruct),1,fpread);
	if(Tbuffer.symbol[0]==symbol[0]){
	  if(nFlag==1){
	    i++;
	     totalMessageCounter++;
	    if(findH(Tbuffer.id)->quantity==Tbuffer.quantity&&findH(Tbuffer.id)->side=='B'){
	      deleteP(&headBuy,&tailBuy,Tbuffer.id);
	    }else if(findH(Tbuffer.id)->quantity==Tbuffer.quantity&&findH(Tbuffer.id)->side=='S'){
	      deleteP(&headSell,&tailSell,Tbuffer.id);
	    }
	  }
	  changeQuantityH(Tbuffer.id,Tbuffer.quantity); 
	}
      }else if(type.messageType=='X'){
	fread(&Xbuffer,sizeof(struct XStruct),1,fpread);
	if(Xbuffer.symbol[0]==symbol[0]){
	  if(nFlag==1){
	    i++;	    
	     totalMessageCounter++;
	    if(findH(Xbuffer.id)->side=='S')
	      deleteP(&headSell,&tailSell,Xbuffer.id); 
	    else
	      deleteP(&headBuy,&tailBuy,Xbuffer.id);
	  }
	  deleteH(Xbuffer.id);	 
	}
      }else if(type.messageType=='R'){
	
	fread(&Rbuffer,sizeof(struct RStruct),1,fpread);
	if(Rbuffer.symbol[0]==symbol[0]){
	  if(nFlag==1){
	    c=0;
	    i++;
	    totalMessageCounter++;
	    if(findH(Rbuffer.id)->side=='B'&&priceChange(Rbuffer.id,Rbuffer.price)){  
	      c=1;
	      deleteP(&headBuy,&tailBuy,Rbuffer.id);
	    }else if(findH(Rbuffer.id)->side=='S'&&priceChange(Rbuffer.id,Rbuffer.price)){
	      c=2;	    
	      deleteP(&headSell,&tailSell,Rbuffer.id);	  
	    }
	  }
	  changePriceAndQuantityH(Rbuffer.id,Rbuffer.quantity,Rbuffer.price);
	  if(nFlag==1){
	    if(c==1)
	      insert(&headBuy,&tailBuy,Rbuffer.id);
	    else if(c==2)     
	      insert(&headSell,&tailSell,Rbuffer.id);
	  }
	}
      }
      
      type.messageType='\0';
      if(i==messageCount&&nFlag==1){
	  printIQ(IQwriter,&headSell,&tailBuy);
	  i=0;

      } 
    }
    printHashmap(fpwrite);
    fclose(fpread);
    fclose(fpwrite); 
    fclose(IQwriter); 
    
  }


  if(bFlag==0){
    fpwrite=fopen("ob.txt","w");
    IQwriter=fopen("iq.txt","w");
    char c;
    int id;
    char side;
    int quantity;
    double price;
    char symbolb[4];
    struct list *headBuy=NULL,*tailBuy=NULL,*headSell=NULL,*tailSell=NULL;
     signal(SIGINT,sigintHandler);
     signal(SIGSEGV,segfaultHandler);
    while((fscanf(fpread,"%c %d",&c,&id))!=EOF){
      if(c=='A'&&findH(id)==NULL){
	fscanf(fpread," %c %s %d %lf\n",&side,symbolb,&quantity,&price);
	if(symbolb[0]==symbol[0]&&symbolb[1]==symbol[1]&&symbolb[2]==symbol[2]&&symbolb[3]==symbol[3]){	
	  newhashmap(id,price,quantity,side);
	  if(nFlag==1){
	    i++;
	    totalMessageCounter++;
	    if(side=='B')
	      insert(&headBuy,&tailBuy,id);
	    else
	      insert(&headSell,&tailSell,id);
	  }
	}
      } else if((c=='C')||(c=='T')){
	fscanf(fpread,"%s %d\n",symbolb,&quantity);
	if(symbolb[0]==symbol[0]&&symbolb[1]==symbol[1]&&symbolb[2]==symbol[2]&&symbolb[3]==symbol[3]){	
	  if(nFlag==1){
	    i++;
	    totalMessageCounter++;
	    if(findH(id)->quantity==quantity&&findH(id)->side=='B')
	      deleteP(&headBuy,&tailBuy,id);
	    else if(findH(id)->quantity==quantity&&findH(id)->side=='S')
	      deleteP(&headSell,&tailSell,id);
	  }
	  changeQuantityH(id,quantity);
	}
      }else if((c=='R')&&checkH(id)){
	fscanf(fpread,"%s %d %lf\n",symbolb,&quantity,&price);
	if(symbolb[0]==symbol[0]&&symbolb[1]==symbol[1]&&symbolb[2]==symbol[2]&&symbolb[3]==symbol[3]){	
	  if(nFlag==1){
	    i++;
	    totalMessageCounter++;
	    if(findH(id)->side=='B')     
	      deleteP(&headBuy,&tailBuy,id);
	    else
	      deleteP(&headSell,&tailSell,id);	  
	  }
	  changePriceAndQuantityH(id,quantity,price);
	  if(nFlag==1){
	    if(findH(id)->side=='B') 
	      insert(&headBuy,&tailBuy,id);
	    else
	      insert(&headSell,&tailSell,id);
	  }
	}
      }else if((c=='X')&&checkH(id)){
	fscanf(fpread,"%s\n",symbolb);
	if(symbolb[0]==symbol[0]&&symbolb[1]==symbol[1]&&symbolb[2]==symbol[2]&&symbolb[3]==symbol[3]){	
	  if(nFlag==1){
	    i++;	
	    
	    totalMessageCounter++;
	    if(findH(id)->side=='S')
	      deleteP(&headSell,&tailSell,id); 
	    else
	      deleteP(&headBuy,&tailBuy,id);
	  }
	  deleteH(id);
	}	
      }
      if(i==messageCount&&nFlag==1){
	printIQ(IQwriter,&headSell,&tailBuy);
	i=0;
      } 
    }

    printHashmap(fpwrite);
    fclose(fpread);
    fclose(fpwrite);  

  }
}

