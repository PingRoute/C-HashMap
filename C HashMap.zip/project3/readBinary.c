struct AStruct{ 
  unsigned int id;
  char side;
  char symbol[4];
  unsigned int quantity;
  double price;
}__attribute__((__packed__));
struct XStruct{
  unsigned int id;
  char symbol[4];
}__attribute__((__packed__));
struct TStruct{
  unsigned int id;
  char symbol[4];
  unsigned int quantity;
}__attribute__((__packed__));

struct CStruct{
  unsigned int id;
  char symbol[4];
  unsigned int quantity;
}__attribute__((__packed__));

struct RStruct{
  unsigned int id;
  char symbol[4];
  unsigned int quantity;
  double price;
}__attribute__((__packed__));

struct readType{
  char messageType;
}__attribute__((__packed__));
