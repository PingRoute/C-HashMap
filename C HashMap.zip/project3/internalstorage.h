int sort(struct list **,struct list **,int );

//struct list *findPositionP(struct list **,struct list **,int);
struct list* findPositionP(struct list **,struct list**,int);

void printIQ( FILE*,struct list**,struct list**);

int deleteP(struct list **, struct list**,int );

void insert(struct list **, struct list**,int );

int priceChange(int id,double price);
